package My_File;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input= new Scanner(System.in);
        ArrayList<Integer> elements = new ArrayList<>();

        System.out.println("enter size of an array");

        int size = input.nextInt();
        System.out.println("enter " + size + " numbers:");

        int value;
        for(value=0; value<size; value++)
      elements.add(value , input.nextInt());

      //long and limited way of Implementing the same function
//        int value1 = input.nextInt();
//        int value2 = input.nextInt();
//        int value3 = input.nextInt();
//        int value4 = input.nextInt();
//        elements.add(value1);
//        elements.add(value2);
//        elements.add(value3);
//        elements.add(value4);

        System.out.println(elements);
        Collections.sort(elements);
        System.out.println("sorted elements : ");
        System.out.println(elements);


        System.out.println("enter the value that you want to check if it exists :");
        int check = input.nextInt();
        if (elements.contains(check))
            System.out.println("value exist ");
        else
            System.out.println("value does not exist");


}}
